Earn Money wizard - Emoney Wizard 1.1

Installation guide:

1. Unpack anywhere on the computer
2. Run setum_emWizard.com
-- If you encounter any warning about unrecognized software just ignore it.
--     This is new application so therefore there can be false wargning
3. Press Next several times

Sincerely
Yours Serchan -- main developer of emWizard :)

http://emwizard.com

If you like application you can donate by paypal to nadtatrou@gmail.com

